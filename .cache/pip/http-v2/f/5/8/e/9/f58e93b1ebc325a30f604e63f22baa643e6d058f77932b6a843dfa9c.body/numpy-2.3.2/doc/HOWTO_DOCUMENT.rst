This document has been replaced, see https://numpydoc.readthedocs.io/en/latest/format.html#docstring-standard
